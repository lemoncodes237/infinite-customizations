scoreboard players set #rollvalue inf-id 0

data modify storage infcust:craft stat set value "inf-sharpness"
data modify storage infcust:craft min set value 3
data modify storage infcust:craft max set value 5
data modify storage infcust:craft operation set value "remove"
data modify storage infcust:craft absmin set value 3
function infcust:craft/ingredients/macro with storage infcust:craft
scoreboard players operation #rollvalue inf-id += #amount inf-id


data modify storage infcust:craft stat set value "inf-armor"
data modify storage infcust:craft min set value -120
data modify storage infcust:craft max set value -60
data modify storage infcust:craft operation set value "add"
data modify storage infcust:craft absmin set value 120
function infcust:craft/ingredients/macro with storage infcust:craft
scoreboard players operation #rollvalue inf-id += #amount inf-id


data modify storage infcust:craft stat set value "inf-atk"
data modify storage infcust:craft min set value 10
data modify storage infcust:craft max set value 30
data modify storage infcust:craft operation set value "remove"
data modify storage infcust:craft absmin set value 10
function infcust:craft/ingredients/macro with storage infcust:craft
scoreboard players operation #rollvalue inf-id += #amount inf-id


data modify storage infcust:craft stat set value "inf-atkspd"
data modify storage infcust:craft min set value 2
data modify storage infcust:craft max set value 4
data modify storage infcust:craft operation set value "remove"
data modify storage infcust:craft absmin set value 2
function infcust:craft/ingredients/macro with storage infcust:craft
scoreboard players operation #rollvalue inf-id += #amount inf-id


data modify storage infcust:craft stat set value "inf-scale"
data modify storage infcust:craft min set value 10
data modify storage infcust:craft max set value 20
data modify storage infcust:craft operation set value "remove"
data modify storage infcust:craft absmin set value 10
function infcust:craft/ingredients/macro with storage infcust:craft
scoreboard players operation #rollvalue inf-id += #amount inf-id


data modify storage infcust:craft stat set value "inf-hp"
data modify storage infcust:craft min set value -30
data modify storage infcust:craft max set value -10
data modify storage infcust:craft operation set value "add"
data modify storage infcust:craft absmin set value 30
function infcust:craft/ingredients/macro with storage infcust:craft
scoreboard players operation #rollvalue inf-id += #amount inf-id



scoreboard players set #divide inf-id 6
scoreboard players operation #rollvalue inf-id /= #divide inf-id

scoreboard players add #temp inf-cost 10

scoreboard players set #inf-detonate inf-id 1