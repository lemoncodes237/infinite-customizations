scoreboard players set #rollvalue inf-id 0

scoreboard players set #inf-photophage inf-id 1

scoreboard players set #rollvalue inf-id 100

scoreboard players add #temp inf-cost 10
