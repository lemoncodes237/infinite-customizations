scoreboard players set #rollvalue inf-id 0

data modify storage infcust:craft stat set value "inf-blockrange"
data modify storage infcust:craft min set value 10
data modify storage infcust:craft max set value 25
data modify storage infcust:craft operation set value "remove"
data modify storage infcust:craft absmin set value 10
function infcust:craft/ingredients/macro with storage infcust:craft
scoreboard players operation #rollvalue inf-id += #amount inf-id


data modify storage infcust:craft stat set value "inf-armor"
data modify storage infcust:craft min set value -8
data modify storage infcust:craft max set value -4
data modify storage infcust:craft operation set value "add"
data modify storage infcust:craft absmin set value 8
function infcust:craft/ingredients/macro with storage infcust:craft
scoreboard players operation #rollvalue inf-id += #amount inf-id


data modify storage infcust:craft stat set value "inf-gravity"
data modify storage infcust:craft min set value 20
data modify storage infcust:craft max set value 60
data modify storage infcust:craft operation set value "remove"
data modify storage infcust:craft absmin set value 20
function infcust:craft/ingredients/macro with storage infcust:craft
scoreboard players operation #rollvalue inf-id += #amount inf-id



scoreboard players set #divide inf-id 3
scoreboard players operation #rollvalue inf-id /= #divide inf-id

scoreboard players add #temp inf-cost 20
